Mechanical Expedition Chinese supplement
Selected community translations: CFPA team and contributors.
https://github.com/CFPAOrg/Minecraft-Mod-Language-Package
Community material is licensed under CC BY-NC-SA 4.0; see LICENSE-CFPA.txt.
Additional translations were prepared for Mechanical Expedition.
