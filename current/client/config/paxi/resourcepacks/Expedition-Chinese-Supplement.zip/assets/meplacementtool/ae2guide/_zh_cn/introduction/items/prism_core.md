---
navigation:
  parent: introduction/index.md
  title: 棱镜原体
  position: 1
  icon: meplacementtool:prism_core
categories:
  - meplacementtool items
item_ids:
  - meplacementtool:prism_core
---

# 棱镜原体

<ItemImage id="meplacementtool:prism_core" scale="4" />

**棱镜原体** 是制作 **<ItemLink id="meplacementtool:key_of_spectrum" />** 的中间合成产物。

<RecipeFor id="meplacementtool:prism_core" />
